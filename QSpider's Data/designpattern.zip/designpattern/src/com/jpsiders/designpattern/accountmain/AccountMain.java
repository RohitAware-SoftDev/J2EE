package com.jpsiders.designpattern.accountmain;

import java.util.Scanner;

import com.jpsiders.designpattern.account.Account;

public class AccountMain {
	private static Account account;
	static Scanner sc;
	static boolean flag=true;
	
	public static void main(String[] args) {
		try {
			while(flag) {
				factory();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		sc.close();
	}
	
	public static Account factory() {
		sc= new Scanner(System.in);
		System.out.println("Ener your choice : ");
		int choice= sc.nextInt();
		System.out.println("1. Withdraw\n 2. Deposite\n 3. CheckBalance\n 4. Exit");
		switch (choice) {
		case 1:
			
		default:
			break;
		}
		return account;
		
	}
}
