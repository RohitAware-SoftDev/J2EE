package com.jpsiders.designpattern;

public class App {

}
