package com.jspiders.factorypattern1.Interface;

public interface Mobile {
	void start();
}
