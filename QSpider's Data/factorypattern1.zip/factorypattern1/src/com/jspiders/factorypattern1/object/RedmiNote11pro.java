package com.jspiders.factorypattern1.object;

import com.jspiders.factorypattern1.Interface.Mobile;

public class RedmiNote11pro implements Mobile{

	@Override
	public void start() {
		System.out.println("You Are Using RedmiNote 11 Pro ");
	}
	
}
