package com.jspiders.factorypattern1.object;

import com.jspiders.factorypattern1.Interface.Mobile;

public class OnePlus9Pro implements Mobile{

	@Override
	public void start() {
		System.out.println("You Are Using One{lus 9 Pro ");
	}

}
