package com.jspiders.factorypattern1.object;

import com.jspiders.factorypattern1.Interface.Mobile;

public class Iphone14ProMax implements Mobile{

	@Override
	public void start() {
		System.out.println("You Are Using iphone 14 ProMax ");
	}
	
}
