package com.jspiders.factorypattern1.app;

public class App {
	
}
